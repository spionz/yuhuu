## 👋 Thank you for the PR!

### Description:

Add short description

### Issue Reference

Add issue reference

### Screenshoot

Add screenshoot if you change the UI

### Minimum Support

- [ ] Click 🌟 button to this repo
- [ ] Follow the Author

### Consider to Support

- 👉 🇮🇩 [Trakteer](https://trakteer.id/mazipan?utm_source=github)
- 👉 🌍 [BuyMeACoffe](https://www.buymeacoffee.com/mazipan?utm_source=github)
- 👉 🌍 [Paypal](https://www.paypal.me/mazipan?utm_source=github)
- 👉 🌍 [Ko-Fi](https://ko-fi.com/mazipan)
